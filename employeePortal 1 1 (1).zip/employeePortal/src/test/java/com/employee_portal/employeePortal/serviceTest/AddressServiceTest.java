package com.employee_portal.employeePortal.serviceTest;


import com.employee_portal.employeePortal.dto.AddressDTO;
import com.employee_portal.employeePortal.entity.Address;
import com.employee_portal.employeePortal.exception.ResourceNotFoundException;
import com.employee_portal.employeePortal.repository.AddressRepository;
import com.employee_portal.employeePortal.service.AddressService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class AddressServiceTest {

    @InjectMocks
    private AddressService addressService;

    @Mock
    private AddressRepository addressRepository;

    @Mock
    private ModelMapper modelMapper;

    Address address;
    AddressDTO addressDTO;

    @BeforeEach
    public void setup(){
         address = new Address(1L , "123" , "myStreet" , "Gurugram" , "281001" , "UP" , "India" );
         addressDTO = new AddressDTO(1L , "123" , "myStreet" , "Gurugram" , "281001" , "UP" , "India" );
    }

    @Test
    public void testCreateAddress(){

        when(modelMapper.map(addressDTO, Address.class)).thenReturn(address);
        when(addressRepository.save(address)).thenReturn(address);
        when(modelMapper.map(address,AddressDTO.class)).thenReturn(addressDTO);

        AddressDTO result = addressService.createAddress(addressDTO);

        assertNotNull(result);
        assertEquals("Gurugram" , result.getCity());
        verify(addressRepository , times(1)).save(address);
    }

    @Test
    public void testGetAllAddresses() {
        when(addressRepository.findAll()).thenReturn(Arrays.asList(address));
        when(modelMapper.map(address, AddressDTO.class)).thenReturn(addressDTO);

        List<AddressDTO> result = addressService.getAllAddress();

        assertEquals(1, result.size());
        assertEquals(addressDTO, result.get(0));
        verify(addressRepository,times(1)).findAll();
    }

    @Test
    public void testGetAddressById_Success() {
        when(addressRepository.findById(1L)).thenReturn(Optional.of(address));
        when(modelMapper.map(address, AddressDTO.class)).thenReturn(addressDTO);

        AddressDTO result = addressService.getAddressById(1L);

        assertEquals(addressDTO, result);
    }

    @Test
    public void testGetAddressById_NotFound() {
        when(addressRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> {
            addressService.getAddressById(1L);
        });
    }

    @Test
    public void testUpdateAddress_Success() {
        when(addressRepository.findById(1L)).thenReturn(Optional.of(address));
        when(addressRepository.save(address)).thenReturn(address);
        when(modelMapper.map(address, AddressDTO.class)).thenReturn(addressDTO);

        AddressDTO result = addressService.updateAddress(1L, addressDTO);

        assertEquals(addressDTO, result);
    }

    @Test
       public void testUpdateAddress_NotFound() {
        when(addressRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> {
            addressService.updateAddress(1L, addressDTO);
        });
    }

    @Test
    public void testDeleteAddress_Success() {
        when(addressRepository.findById(1L)).thenReturn(Optional.of(address));

        assertDoesNotThrow(() -> {
            addressService.deleteAddress(1L);
        });

        verify(addressRepository, times(1)).delete(address);
    }

    @Test
    public void testDeleteAddress_NotFound() {
        when(addressRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> {
            addressService.deleteAddress(1L);
        });
    }


}
