package com.employee_portal.employeePortal.ControllerTest;

import com.employee_portal.employeePortal.controller.AddressController;
import com.employee_portal.employeePortal.dto.AddressDTO;
import com.employee_portal.employeePortal.service.AddressService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class AddressControllerTest {

    @InjectMocks
    private AddressController addressController;

    @Mock
    private AddressService addressService;

    private AddressDTO addressDTO;

    @BeforeEach
    public void setUp() {
        addressDTO = new AddressDTO(1L , "123" , "myStreet" , "Gurugram" , "281001" , "UP" , "India" );
    }

    @Test
    public void testGetAllAddresses(){
        List<AddressDTO> addressList = Arrays.asList(addressDTO);
        when(addressService.getAllAddress()).thenReturn(addressList);
        ResponseEntity<List<AddressDTO>> response = addressController.getAllAddresses();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(addressList, response.getBody());

        verify(addressService, times(1)).getAllAddress();

    }

    @Test
    public void testGetAddressById(){
        long id = 1L;
        when(addressService.getAddressById(id)).thenReturn(addressDTO);
        ResponseEntity<AddressDTO> response = addressController.getByID(id);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(addressDTO, response.getBody());

        verify(addressService, times(1)).getAddressById(id);
    }

    @Test
    public void testCreateAddress(){
        when(addressService.createAddress(addressDTO)).thenReturn(addressDTO);
        ResponseEntity<AddressDTO> response = addressController.createAddress(addressDTO);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(addressDTO, response.getBody());

        verify(addressService, times(1)).createAddress(addressDTO);
    }

    @Test
    public void testUpdateAddress(){
        long id = 1L;
        AddressDTO updatedDTO = new AddressDTO(1L , "123 A" , "myStreet" , "Gurugram" , "281001" , "UP" , "India");

        when(addressService.updateAddress(id, updatedDTO)).thenReturn(updatedDTO);
        ResponseEntity<AddressDTO> response = addressController.updateAddress(id, updatedDTO);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(updatedDTO, response.getBody());

        verify(addressService, times(1)).updateAddress(id, updatedDTO);
    }

    @Test
    public void testDeleteAddressById(){
        long id = 1L;

        ResponseEntity<String> response = addressController.deleteAddress(id);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Address Deleted Successfully !!!", response.getBody());

        verify(addressService, times(1)).deleteAddress(id);
    }

}
