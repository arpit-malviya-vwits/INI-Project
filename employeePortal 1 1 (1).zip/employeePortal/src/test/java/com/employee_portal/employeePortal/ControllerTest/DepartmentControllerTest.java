package com.employee_portal.employeePortal.ControllerTest;

import com.employee_portal.employeePortal.controller.DepartmentController;
import com.employee_portal.employeePortal.dto.DepartmentDTO;
import com.employee_portal.employeePortal.service.DepartmentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class DepartmentControllerTest {

    @InjectMocks
    private DepartmentController departmentController;

    @Mock
    private DepartmentService departmentService;

    private DepartmentDTO departmentDTO;

    @BeforeEach
    public void setUp() {
        departmentDTO = new DepartmentDTO(1L, "IT");
    }

    @Test
    public void testGetAllDepartments() {
        List<DepartmentDTO> departments = Arrays.asList(
                new DepartmentDTO(1L, "SDC"),
                new DepartmentDTO(2L, "IT")
        );

        when(departmentService.getAllDepartments()).thenReturn(departments);

        ResponseEntity<List<DepartmentDTO>> response = departmentController.getAllDepartments();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(2, response.getBody().size());
    }

    @Test
    public void testGetDepartmentByID(){
        long departmentId = 1L;
        DepartmentDTO departmentDTO = new DepartmentDTO(1L,"SDC");

        when(departmentService.getById(departmentId)).thenReturn(departmentDTO);

        ResponseEntity<DepartmentDTO> response = departmentController.getDepartmentById(departmentId);

        assertEquals(HttpStatus.OK,response.getStatusCode());
        assertEquals("SDC",response.getBody().getName());
        verify(departmentService, times(1)).getById(departmentId);
    }

    @Test
    public void testCreateDepartment(){
        DepartmentDTO requestDTO = new DepartmentDTO( 1L, "SDC");

        when(departmentService.createDepartment(requestDTO)).thenReturn(departmentDTO);

        ResponseEntity<DepartmentDTO> response = departmentController.createDepartment(requestDTO);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(departmentDTO, response.getBody());

        verify(departmentService, times(1)).createDepartment(requestDTO);
    }

    @Test
    public void testUpdateDepartment(){
        long id = 1L;
        DepartmentDTO updatedDTO = new DepartmentDTO(id, "Updated IT");

        when(departmentService.updateDepartment(id, updatedDTO)).thenReturn(updatedDTO);
        ResponseEntity<DepartmentDTO> response = departmentController.updateDepartment(id, updatedDTO);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(updatedDTO, response.getBody());

        verify(departmentService, times(1)).updateDepartment(id, updatedDTO);
    }

    @Test
    public void testDeleteDepartment(){
        long id = 1L;

        ResponseEntity<String> response = departmentController.deleteDepartment(id);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Department Deleted Successfully !!!", response.getBody());

        verify(departmentService, times(1)).deleteById(id);
    }


}
