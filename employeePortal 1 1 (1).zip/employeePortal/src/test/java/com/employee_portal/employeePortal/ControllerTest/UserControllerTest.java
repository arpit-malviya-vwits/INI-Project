package com.employee_portal.employeePortal.ControllerTest;


import com.employee_portal.employeePortal.controller.UserController;
import com.employee_portal.employeePortal.dto.AddressDTO;
import com.employee_portal.employeePortal.dto.DepartmentDTO;
import com.employee_portal.employeePortal.dto.UserDTO;
import com.employee_portal.employeePortal.entity.Role;
import com.employee_portal.employeePortal.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class UserControllerTest {

    @InjectMocks
    private UserController userController;

    @Mock
    private UserService userService;

    UserDTO userDTO;
    AddressDTO addressDTO;
    DepartmentDTO departmentDTO;

    @BeforeEach
    public void setUp(){
        userDTO = new UserDTO(1L , "mohan", "mohan@gmail.com", "ABCD", "1234567890", Role.EMPLOYEE,"Pune" , "mohan"  , departmentDTO,addressDTO );
        departmentDTO = new DepartmentDTO(1L,"SDC");
        addressDTO = new AddressDTO(1L , "123" , "myStreet" , "Gurugram" , "281001" , "UP" , "India" );
    }

    @Test
    public void testGetAllUsers() {
        when(userService.getAllEmployees()).thenReturn(Arrays.asList(userDTO));
        ResponseEntity<List<UserDTO>> response = userController.getUserDetails();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody().size());

    }

    @Test
    public void testGetUserById() {
        long id = 1L;
        when(userService.getById(id)).thenReturn(userDTO);
        ResponseEntity<UserDTO> response = userController.getUserById(1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("mohan", response.getBody().getName());
    }

    @Test
    public void testCreateUser(){
        when(userService.createEmployee(userDTO)).thenReturn(userDTO);

        ResponseEntity<UserDTO> response = userController.createUser(userDTO);

        assertEquals(HttpStatus.CREATED , response.getStatusCode());
        assertEquals("mohan" , response.getBody().getName());
    }

    @Test
    public void testUpdateUser(){
        long id = 1L;
        UserDTO updatedUser = new UserDTO(1L , "mohan kumar", "mohan@gmail.com", "ABCD", "1234567890", Role.EMPLOYEE,"Pune" , "mohan"  , departmentDTO,addressDTO );

        when(userService.updateEmployee(id ,updatedUser)).thenReturn(updatedUser);
        ResponseEntity<UserDTO> response = userController.updateUser(id ,updatedUser);

        assertEquals(HttpStatus.OK , response.getStatusCode());
        assertEquals(updatedUser, response.getBody());
    }

    @Test
    public void testDeleteUser(){
        long id = 1L;

        ResponseEntity<String> response = userController.deleteUserById(id);

        assertEquals(HttpStatus.OK , response.getStatusCode());
        assertEquals("Employee Deleted Successfully !!!" , response.getBody());
    }

    @Test
    public void testUpdateUserAddress(){
        long id = 1L;

        when(userService.updateUserAddress(id , addressDTO)).thenReturn(userDTO);

        ResponseEntity<UserDTO> response = userController.updateUserAddress(id, addressDTO);

        assertEquals(HttpStatus.OK , response.getStatusCode());
        assertEquals(userDTO , response.getBody());
    }

    @Test
    public void testupdateUserDepartment(){
        long id = 1L ;

        when(userService.updateUserDepartment(id , departmentDTO)).thenReturn(userDTO);

        ResponseEntity<UserDTO> response = userController.updateUserDepartment(id , departmentDTO);

        assertEquals(HttpStatus.OK,response.getStatusCode());
        assertEquals(userDTO , response.getBody());
    }

}
