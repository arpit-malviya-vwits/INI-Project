package com.employee_portal.employeePortal.serviceTest;


import com.employee_portal.employeePortal.dto.DepartmentDTO;
import com.employee_portal.employeePortal.entity.Department;
import com.employee_portal.employeePortal.exception.ResourceNotFoundException;
import com.employee_portal.employeePortal.repository.DepartmentRepository;
import com.employee_portal.employeePortal.repository.UserRepository;
import com.employee_portal.employeePortal.service.DepartmentService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class DepartmentServiceTest {

    @Mock
    private DepartmentRepository departmentRepository;

    @Mock
    private UserRepository userRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private DepartmentService departmentService;

    private Department department;
    private DepartmentDTO departmentDTO;

    @BeforeEach
    void setUp() {
        department = new Department(1L,"SDC");
        departmentDTO = new DepartmentDTO(1L,"SDC");
    }

    @Test
    void testCreateDepartment() {
        when(modelMapper.map(departmentDTO, Department.class)).thenReturn(department);
        when(departmentRepository.save(department)).thenReturn(department);
        when(modelMapper.map(department, DepartmentDTO.class)).thenReturn(departmentDTO);

        DepartmentDTO result = departmentService.createDepartment(departmentDTO);

        assertNotNull(result);
        assertEquals("SDC", result.getName());
        verify(departmentRepository, times(1)).save(department);
    }

    @Test
    void testGetAllDepartments() {
        when(departmentRepository.findAll()).thenReturn(Arrays.asList(department));
        when(modelMapper.map(department, DepartmentDTO.class)).thenReturn(departmentDTO);

        List<DepartmentDTO> result = departmentService.getAllDepartments();

        assertEquals(1, result.size());
        assertEquals("SDC", result.get(0).getName());
        verify(departmentRepository, times(1)).findAll();
    }

    @Test
    void testGetById_Success() {
        when(departmentRepository.findById(1L)).thenReturn(Optional.of(department));
        when(modelMapper.map(department, DepartmentDTO.class)).thenReturn(departmentDTO);

        DepartmentDTO result = departmentService.getById(1L);

        assertNotNull(result);
        assertEquals("SDC", result.getName());
        verify(departmentRepository, times(1)).findById(1L);
    }

    @Test
    void testGetById_NotFound() {
        when(departmentRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> {
            departmentService.getById(1L);
        });

        verify(departmentRepository, times(1)).findById(1L);
    }

    @Test
    void testUpdateDepartment_Success() {

        when(departmentRepository.findById(1L)).thenReturn(Optional.of(department));
        when(departmentRepository.save(department)).thenReturn(department);
        when(modelMapper.map(department, DepartmentDTO.class)).thenReturn(departmentDTO);

        DepartmentDTO result = departmentService.updateDepartment(1L, departmentDTO);

        assertNotNull(result);
        assertEquals("SDC", result.getName());
        verify(departmentRepository, times(1)).findById(1L);
    }

    @Test
    public void testUpdateDepartment_NotFound() {
        when(departmentRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> departmentService.updateDepartment(1L, departmentDTO));
    }

    @Test
    void testDeleteById_Success(){
        when(departmentRepository.findById(1L)).thenReturn(Optional.of(department));

        departmentService.deleteById(1L);

        verify(departmentRepository,times(1)).delete(department);
    }

    @Test
    public void testDeleteById_NotFound() {
        when(departmentRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> departmentService.deleteById(1L));
    }

}
