package com.employee_portal.employeePortal.serviceTest;


import com.employee_portal.employeePortal.dto.AddressDTO;
import com.employee_portal.employeePortal.dto.DepartmentDTO;
import com.employee_portal.employeePortal.dto.UserDTO;
import com.employee_portal.employeePortal.entity.Address;
import com.employee_portal.employeePortal.entity.Department;
import com.employee_portal.employeePortal.entity.Role;
import com.employee_portal.employeePortal.entity.User;
import com.employee_portal.employeePortal.exception.ResourceNotFoundException;
import com.employee_portal.employeePortal.repository.AddressRepository;
import com.employee_portal.employeePortal.repository.DepartmentRepository;
import com.employee_portal.employeePortal.repository.UserRepository;
import com.employee_portal.employeePortal.service.AddressService;
import com.employee_portal.employeePortal.service.DepartmentService;
import com.employee_portal.employeePortal.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private DepartmentRepository departmentRepository;

    @Mock
    private AddressRepository addressRepository;

    @Mock
    private ModelMapper modelMapper;

    @Mock
    private AddressService addressService;

    @Mock
    private DepartmentService departmentService;

    @InjectMocks
    private UserService userService;

    User user ;
    UserDTO userDTO;
    Address address;
    AddressDTO addressDTO;
    Department department;
    DepartmentDTO departmentDTO;

    @BeforeEach
    void setUp(){

        address = new Address(1L , "123" , "myStreet" , "Gurugram" , "281001" , "UP" , "India" );
        addressDTO = new AddressDTO(1L , "123" , "myStreet" , "Gurugram" , "281001" , "UP" , "India" );

        department = new Department(1L,"SDC");
        departmentDTO = new DepartmentDTO(1L,"SDC");

        user = new User(1L , "mohan", "mohan@gmail.com", "ABCD", "1234567890", Role.EMPLOYEE,"Pune" , "mohan"  , address, department );
        userDTO = new UserDTO(1L , "mohan", "mohan@gmail.com", "ABCD" , "1234567890", Role.EMPLOYEE,"Pune", "mohan"  , departmentDTO , addressDTO);

    }

    @Test
    public void testGetAllUsers() {
        when(userRepository.findAll()).thenReturn(Arrays.asList(user));
        when(modelMapper.map(user, UserDTO.class)).thenReturn(userDTO);

        List<UserDTO> result = userService.getAllEmployees();

        assertEquals(1, result.size());
        assertEquals(userDTO, result.get(0));
    }

    @Test
    public void testGetById() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(modelMapper.map(user, UserDTO.class)).thenReturn(userDTO);

        UserDTO result = userService.getById(1L);

        assertEquals(userDTO, result);
    }

    @Test
    public void testGetById_NotFound() {
        when(userRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> {
            userService.getById(1L);
        });
    }

    @Test
    public void testCreateUser() {
        when(modelMapper.map(userDTO, User.class)).thenReturn(user);
        when(modelMapper.map(addressDTO,Address.class)).thenReturn(address);
        when(departmentRepository.findById(1L)).thenReturn(Optional.of(department));
        when(userRepository.existsByEmail(userDTO.getEmail())).thenReturn(false);
        when(userRepository.save(user)).thenReturn(user);
        when(modelMapper.map(user, UserDTO.class)).thenReturn(userDTO);

        UserDTO result = userService.createEmployee(userDTO);

        assertNotNull(result);
        assertEquals(userDTO, result);
    }



    @Test
    public void testDeleteById() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));

        assertDoesNotThrow(() -> {
            userService.deleteById(1L);
        });

        verify(userRepository, times(1)).delete(user);
    }

    @Test
    public void testDeleteById_NotFound() {
        when(userRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> {
            userService.deleteById(1L);
        });
    }

    @Test
    public void testUpdateUser_Success() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(departmentRepository.findById(1L)).thenReturn(Optional.of(department));
        when(userRepository.save(user)).thenReturn(user);
        when(modelMapper.map(user, UserDTO.class)).thenReturn(userDTO);

        UserDTO result = userService.updateEmployee(1L, userDTO);

        assertEquals(userDTO, result);
    }

    @Test
    public void testUpdateUser_NotFound() {
        when(userRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> {
            userService.updateEmployee(1L, userDTO);
        });
    }

    @Test
    public void testUpdateUserAddress_Success() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(modelMapper.map(userDTO.getAddress(), Address.class)).thenReturn(address);
        when(addressRepository.save(address)).thenReturn(address);
        when(userRepository.save(user)).thenReturn(user);
        when(modelMapper.map(user, UserDTO.class)).thenReturn(userDTO);

        UserDTO result = userService.updateUserAddress(1L, addressDTO);

        assertEquals(userDTO, result);
    }

    @Test
    public void testUpdateUserAddress_UserNotFound() {
        when(userRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> {
            userService.updateUserAddress(1L, addressDTO);
        });
    }

    @Test
    public void testUpdateUserDepartment_Success() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(departmentRepository.findByName("SDC")).thenReturn(Optional.of(department));
        when(userRepository.save(user)).thenReturn(user);
        when(modelMapper.map(user, UserDTO.class)).thenReturn(userDTO);

        UserDTO result = userService.updateUserDepartment(1L, departmentDTO);

        assertEquals(userDTO, result);
    }

    @Test
    public void testUpdateUserDepartment_UserNotFound() {
        when(userRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> {
            userService.updateUserDepartment(1L, departmentDTO);
        });
    }

    @Test
    public void testUpdateUserDepartment_DepartmentNotFound() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(departmentRepository.findByName(departmentDTO.getName())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> {
            userService.updateUserDepartment(1L, departmentDTO);
        });
    }
}
