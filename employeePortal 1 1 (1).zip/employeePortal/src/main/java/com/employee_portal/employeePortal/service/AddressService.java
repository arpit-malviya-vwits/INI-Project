package com.employee_portal.employeePortal.service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee_portal.employeePortal.dto.AddressDTO;
import com.employee_portal.employeePortal.entity.Address;
import com.employee_portal.employeePortal.exception.ResourceNotFoundException;
import com.employee_portal.employeePortal.repository.AddressRepository;

@Service
public class AddressService {
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private AddressRepository addressRepository;
	
	
	//  Get all address 
	
	public List<AddressDTO> getAllAddress(){
		
		List<Address> addresses = addressRepository.findAll();
		
		return addresses.stream()
				.map(this:: convertToDTO)
				.collect(Collectors.toList());
	}
	
	
	// Get by ID
	
	public AddressDTO getAddressById(long id) {
		Address address = addressRepository.findById(id)
							.orElseThrow(() -> new ResourceNotFoundException("Address not Found !"));
		
		return convertToDTO(address);
	}
	
	
	// Create address
	
	public AddressDTO createAddress(AddressDTO addressDto) {
		Address address = convertToEntity(addressDto);
		
		Address savedAddress = addressRepository.save(address);
		
		return convertToDTO(savedAddress);
	}
	
	
	// update address 
	
	public AddressDTO updateAddress(long id,AddressDTO addressDto) {
		Address existingAddress = addressRepository.findById(id)
										.orElseThrow(() -> new ResourceNotFoundException("Address not exist with that ID !"));

		existingAddress.setCity(addressDto.getCity());
		existingAddress.setCountry(addressDto.getCountry());
		existingAddress.setHouseNo(addressDto.getHouseNo());
		existingAddress.setState(addressDto.getState());
		existingAddress.setStreet(addressDto.getStreet());
		existingAddress.setZip(addressDto.getZip());

		Address addressResponse = addressRepository.save(existingAddress);
		return convertToDTO(addressResponse);
	}
	
	
	//delete address
	
	public void deleteAddress(long id) {
		Address address = addressRepository.findById(id)
									.orElseThrow(() -> new ResourceNotFoundException("Address does not exist with that ID!"));
		
		addressRepository.delete(address);
	}
	
	
	// ModelMapper Methods to Map DTO and ENTITY 
	
	public AddressDTO convertToDTO(Address address) {
		return modelMapper.map(address, AddressDTO.class);
	}
	
	public Address convertToEntity(AddressDTO addressDto) {
		return modelMapper.map(addressDto, Address.class);
	}
	
}
