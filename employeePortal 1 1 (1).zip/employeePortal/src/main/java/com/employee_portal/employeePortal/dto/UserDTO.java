package com.employee_portal.employeePortal.dto;

import com.employee_portal.employeePortal.entity.Role;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDTO {
	
	private long id;
	private String name;
	private String email;
	private String userId;
	private String contactNo;
	private Role role;
	private String location;
	private String password;
	private DepartmentDTO department;
	private AddressDTO address;

}
