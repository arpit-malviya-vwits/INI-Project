package com.employee_portal.employeePortal.entity;

public enum Role {
	EMPLOYEE,
	ADMIN
}
