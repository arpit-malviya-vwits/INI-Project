package com.employee_portal.employeePortal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.employee_portal.employeePortal.dto.AddressDTO;
import com.employee_portal.employeePortal.service.AddressService;

@RestController
@RequestMapping("/user/address")
@CrossOrigin(origins = "http://localhost:4200")
public class AddressController {

	@Autowired
	private AddressService addressService;
	
	
	// Create Address 
	
	@PostMapping
	public ResponseEntity<AddressDTO> createAddress(@RequestBody AddressDTO addressDto){
		return new ResponseEntity<AddressDTO>(addressService.createAddress(addressDto),HttpStatus.CREATED);
	}
	
	
	//Get by ID
	
	@GetMapping("/{id}")
	public ResponseEntity<AddressDTO> getByID(@PathVariable long id ){
		return new ResponseEntity<AddressDTO>(addressService.getAddressById(id),HttpStatus.OK);
	}
	
	
	//Get All Address
	
	@GetMapping()
	public ResponseEntity<List<AddressDTO>> getAllAddresses(){
		return new ResponseEntity<List<AddressDTO>>(addressService.getAllAddress(),HttpStatus.OK);
	}
	
	
	// Update Address 
	
	@PutMapping("/{id}")
	public ResponseEntity<AddressDTO> updateAddress(@PathVariable long id , @RequestBody AddressDTO addressDto){
		return new ResponseEntity<AddressDTO>(addressService.updateAddress(id, addressDto),HttpStatus.OK);
	}
	
	
	// Delete Address

	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteAddress(@PathVariable long id){
		addressService.deleteAddress(id);
		return new ResponseEntity<String>("Address Deleted Successfully !!!" , HttpStatus.OK);
	}
	
}
