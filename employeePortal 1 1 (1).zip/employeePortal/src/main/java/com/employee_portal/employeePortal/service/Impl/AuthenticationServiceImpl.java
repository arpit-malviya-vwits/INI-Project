package com.employee_portal.employeePortal.service.Impl;

import com.employee_portal.employeePortal.dto.JwtAuthenticationResponse;
import com.employee_portal.employeePortal.dto.SignInRequest;
import com.employee_portal.employeePortal.dto.SignUpRequest;
import com.employee_portal.employeePortal.entity.Role;
import com.employee_portal.employeePortal.entity.User;
import com.employee_portal.employeePortal.exception.ResourceNotFoundException;
import com.employee_portal.employeePortal.repository.UserRepository;
import com.employee_portal.employeePortal.service.AuthenticationService;
import com.employee_portal.employeePortal.service.JWTService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.HashMap;

@Service
@RequiredArgsConstructor
public class AuthenticationServiceImpl implements AuthenticationService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JWTService jwtService;

    @Autowired
    private ModelMapper modelMapper;

    public User signUp(SignUpRequest signUpRequest){
        User user = new User();

        modelMapper.map(signUpRequest,user);
        user.setPassword(passwordEncoder.encode(signUpRequest.getPassword()));
        user.setRole(Role.EMPLOYEE);

        return userRepository.save(user);
    }

    public JwtAuthenticationResponse signIn(SignInRequest signInRequest){
        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(signInRequest.getEmail(),signInRequest.getPassword()));
        var user = userRepository.findByEmail(signInRequest.getEmail()).orElseThrow(() -> new ResourceNotFoundException("Invalid Email or Password !!"));

        var jwt = jwtService.generateToken(user,user.getId());

        JwtAuthenticationResponse jwtAuthenticationResponse = new JwtAuthenticationResponse();

        jwtAuthenticationResponse.setToken(jwt);

        return jwtAuthenticationResponse;
    }
}
