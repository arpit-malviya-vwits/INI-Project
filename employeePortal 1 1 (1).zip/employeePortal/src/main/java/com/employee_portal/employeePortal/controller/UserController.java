package com.employee_portal.employeePortal.controller;

import java.util.List;

import com.employee_portal.employeePortal.dto.AddressDTO;
import com.employee_portal.employeePortal.dto.DepartmentDTO;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.employee_portal.employeePortal.dto.UserDTO;
import com.employee_portal.employeePortal.service.UserService;

@RestController
@RequestMapping("user")
@CrossOrigin(origins = "http://localhost:4200")
public class UserController {
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	UserService userService;
	
	// Get All Employee
	
	@GetMapping
	public ResponseEntity<List<UserDTO>> getUserDetails(){
		return new ResponseEntity<List<UserDTO>>(userService.getAllEmployees(),HttpStatus.OK);
	}
	
	// Get Employee By Id
	
	@GetMapping("/{id}")
	public ResponseEntity<UserDTO> getUserById(@PathVariable long id) {
		return  new ResponseEntity<UserDTO>(userService.getById(id),HttpStatus.OK);
	}
	
	
	// Create Employee
	
	@PostMapping
	public ResponseEntity<UserDTO> createUser(@RequestBody UserDTO employeeDto) {
		return new ResponseEntity<UserDTO>(userService.createEmployee(employeeDto),HttpStatus.CREATED);
	}
	
	
	// Update Employee 
	
	@PutMapping("/{id}")
	public ResponseEntity<UserDTO> updateUser(@PathVariable long id , @RequestBody UserDTO employeeDto ) {
		return new ResponseEntity<UserDTO>(userService.updateEmployee(id, employeeDto),HttpStatus.OK);
	}
	
	
	// Delete Employee By ID
	
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteUserById(@PathVariable long id) {
		userService.deleteById(id);
		return new ResponseEntity<String>("Employee Deleted Successfully !!!", HttpStatus.OK);
	}

	// update Address of existing user

	@PutMapping("/{id}/address")
	public ResponseEntity<UserDTO> updateUserAddress(@PathVariable long id , @RequestBody AddressDTO addressDTO){
		return new ResponseEntity<UserDTO>(userService.updateUserAddress(id , addressDTO) , HttpStatus.OK);
	}

	// update  Department of existing user

	@PostMapping("/{id}/department")
	public ResponseEntity<UserDTO> updateUserDepartment(@PathVariable long id , @RequestBody DepartmentDTO departmentDTO){
		return new ResponseEntity<UserDTO>(userService.updateUserDepartment(id , departmentDTO) , HttpStatus.OK);
	}
}
