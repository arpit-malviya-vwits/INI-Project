package com.employee_portal.employeePortal.service;

import com.employee_portal.employeePortal.dto.JwtAuthenticationResponse;
import com.employee_portal.employeePortal.dto.SignInRequest;
import com.employee_portal.employeePortal.dto.SignUpRequest;
import com.employee_portal.employeePortal.entity.User;

public interface AuthenticationService {
    User signUp(SignUpRequest signUpRequest);

    JwtAuthenticationResponse signIn(SignInRequest signInRequest);
}
