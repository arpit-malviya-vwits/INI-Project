package com.employee_portal.employeePortal.controller;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import com.employee_portal.employeePortal.exception.ErrorDetails;
import com.employee_portal.employeePortal.exception.ResourceNotFoundException;

@ControllerAdvice
@CrossOrigin(origins = "http://localhost:4200")
public class ExceptionController {
	
	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<Object> handleResourceNotFoundException(ResourceNotFoundException ex ,WebRequest request){
		ErrorDetails errordetails = new ErrorDetails(new Date(), ex.getMessage(), request.getDescription(false));
		
		return new ResponseEntity<Object>(errordetails,HttpStatus.NOT_FOUND);
	}
	
}
