package com.employee_portal.employeePortal.repository;

import com.employee_portal.employeePortal.entity.Department;
import com.employee_portal.employeePortal.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.employee_portal.employeePortal.entity.User;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
	public boolean existsByEmail(String email);
	Optional<User> findByEmail(String email);
	User[] findByRole(Role role);
	List<User> findByDepartment(Department department);
}