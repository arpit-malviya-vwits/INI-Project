package com.employee_portal.employeePortal.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class DepartmentDTO {
	
	private long id ;
	private String name;
	
}
