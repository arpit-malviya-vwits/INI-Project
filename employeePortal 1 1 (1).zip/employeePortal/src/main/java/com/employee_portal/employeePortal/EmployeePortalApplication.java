package com.employee_portal.employeePortal;

import com.employee_portal.employeePortal.entity.Address;
import com.employee_portal.employeePortal.entity.Role;
import com.employee_portal.employeePortal.entity.User;
import com.employee_portal.employeePortal.repository.UserRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@SpringBootApplication
public class EmployeePortalApplication  implements CommandLineRunner {

    @Bean
    ModelMapper modelMapper() {
		return new ModelMapper();
	}

	@Autowired
	private UserRepository userRepository;
	
	public static void main(String[] args) {
		SpringApplication.run(EmployeePortalApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		User adminAccount[] = userRepository.findByRole(Role.ADMIN);

		if(adminAccount.length == 0 ){
			User user = new User();

			user.setEmail("admin@gmail.com");
			user.setPassword(new BCryptPasswordEncoder().encode("admin123"));
			user.setName("Admin");
			user.setRole(Role.ADMIN);
			user.setAddress(new Address());

			userRepository.save(user);
		}
	}
}
