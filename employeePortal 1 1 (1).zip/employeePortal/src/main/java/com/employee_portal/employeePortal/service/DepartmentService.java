package com.employee_portal.employeePortal.service;

import java.util.List;
import java.util.stream.Collectors;

import com.employee_portal.employeePortal.entity.User;
import com.employee_portal.employeePortal.repository.UserRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee_portal.employeePortal.dto.DepartmentDTO;
import com.employee_portal.employeePortal.entity.Department;
import com.employee_portal.employeePortal.exception.ResourceNotFoundException;
import com.employee_portal.employeePortal.repository.DepartmentRepository;

@Service
public class DepartmentService {

	@Autowired
	private DepartmentRepository departmentRepository ;
	
	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private UserRepository userRepository;
	
	// Get All Departments
	
	public List<DepartmentDTO> getAllDepartments(){
		 List<Department> departments =  departmentRepository.findAll();
		 
		 return	 departments.stream()
				 		.map(this::convertToDTO)
				 		.collect(Collectors.toList());
	}
	
	
	// Get Department By ID 
	
	public DepartmentDTO getById(long id) {		
		Department department =  departmentRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("No Department exist with that ID !"));
		
		return convertToDTO(department);
	}
	
	
	// Create Department 
	
	public DepartmentDTO createDepartment(DepartmentDTO departmentDto) {
		Department departmentRequest = convertToEntity(departmentDto);
			Department savedDepartment = departmentRepository.save(departmentRequest);
			
			return convertToDTO(savedDepartment);
	}
		
	
	// Update Department 
	
	public DepartmentDTO updateDepartment(long id , DepartmentDTO departmentDto) {
		Department existingdepartment = departmentRepository.findById(id)
												.orElseThrow(() -> new ResourceNotFoundException(" No Department exist with that ID !"));

		existingdepartment.setName(departmentDto.getName());
		Department updatedDepartment = departmentRepository.save(existingdepartment);
		
		return convertToDTO(updatedDepartment);
		
	}
	
	
	// Delete Department 
	
	public void deleteById(long id) {
		Department department = departmentRepository.findById(id)
									.orElseThrow(() -> new ResourceNotFoundException("No Such Department Exist !"));

		List<User> users = userRepository.findByDepartment(department);
		for (User user : users) {
			user.setDepartment(null);
		}

		userRepository.saveAll(users);
		departmentRepository.delete(department);
	}
	
	
	// ModelMapper Methods to Map DTO and ENTITY 
	
	private DepartmentDTO convertToDTO(Department department) {
		return modelMapper.map(department, DepartmentDTO.class);
	}
	
	private Department convertToEntity(DepartmentDTO departmentDto) {
		return modelMapper.map(departmentDto, Department.class);
	}
	
}
