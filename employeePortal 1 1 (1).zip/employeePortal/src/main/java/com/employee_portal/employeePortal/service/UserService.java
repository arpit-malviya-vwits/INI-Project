package com.employee_portal.employeePortal.service;

import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import com.employee_portal.employeePortal.dto.AddressDTO;
import com.employee_portal.employeePortal.dto.DepartmentDTO;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.employee_portal.employeePortal.dto.UserDTO;
import com.employee_portal.employeePortal.entity.Address;
import com.employee_portal.employeePortal.entity.Department;
import com.employee_portal.employeePortal.entity.User;
import com.employee_portal.employeePortal.exception.ResourceNotFoundException;
import com.employee_portal.employeePortal.repository.AddressRepository;
import com.employee_portal.employeePortal.repository.DepartmentRepository;
import com.employee_portal.employeePortal.repository.UserRepository;


@Service
public class UserService{
	
	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private AddressService addressService;
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private DepartmentRepository departmentRepository;
	
	@Autowired
	private AddressRepository addressRepository;

	// Get All Employees 
	
	public List<UserDTO> getAllEmployees(){
		List<User> employees =  userRepo.findAll();
		return employees.stream()
						.map(this::convertToDTO)
						.collect(Collectors.toList());
	}

	// Get Employee by ID
	
	public UserDTO getById(long id) {
		User employee = userRepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("No Employee exist with that ID !"));
		return convertToDTO(employee);
	}

	// Create New User
	
	boolean isValidEmail(String email) {
		String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,}$";
		return Pattern.matches(emailRegex, email);
	}

	
	public UserDTO createEmployee(UserDTO userDto) {
		
		User employee = convertToEntity(userDto);

		employee.setPassword(passwordEncoder.encode(userDto.getPassword()));
		
		if(userDto.getAddress() != null) {
			Address address = modelMapper.map(userDto.getAddress(), Address.class);
			employee.setAddress(address);
		}
		
		if(userDto.getDepartment() != null) {
			Department department = departmentRepository.findByName(userDto.getDepartment().getName())
											.orElseThrow(() -> new ResourceNotFoundException("No Department Found of that ID !  Please Enter the department Name "));
			employee.setDepartment(department);
		}
		
		if(isValidEmail(userDto.getEmail()) && !userRepo.existsByEmail(userDto.getEmail())) {
			User employeeResponse = userRepo.save(employee);
			return convertToDTO(employeeResponse);
		}
		
		throw new ResourceNotFoundException("Invalid Email Type !");

	}

	// Delete Employee by ID 
	
	public void deleteById(long id) {

		User employee = userRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee does not exist with that ID !"));

		userRepo.delete(employee);
	}

	// Update Employee
	
	public UserDTO updateEmployee(long id , UserDTO userDTO) {
		
		User existingEmployee = userRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("No Employee exist with that ID !"));
		
		existingEmployee.setName(userDTO.getName());
		existingEmployee.setEmail(userDTO.getEmail());
		existingEmployee.setUserId(userDTO.getUserId());
		existingEmployee.setContactNo(userDTO.getContactNo());
		existingEmployee.setRole(userDTO.getRole());
		existingEmployee.setLocation(userDTO.getLocation());

		if(userDTO.getAddress() != null){
			existingEmployee.setAddress(addressService.convertToEntity(userDTO.getAddress()));
		}

		if(userDTO.getDepartment() != null) {
			Department department = departmentRepository.findById(userDTO.getDepartment().getId())
											.orElseThrow(() -> new ResourceNotFoundException("No Such Department exist with that ID !"));
			existingEmployee.setDepartment(department);
		}
		
		User updatedEmployee = userRepo.save(existingEmployee);
		
		return convertToDTO(updatedEmployee);
	}

	// Add User Address

	public UserDTO updateUserAddress(long id , AddressDTO addressDTO){
		User user = userRepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("No Such User Exists !! "));

		Address address = modelMapper.map(addressDTO,Address.class);
		addressRepository.save(address);
		user.setAddress(address);
		User updatedUser = userRepo.save(user);

		return convertToDTO(updatedUser);
	}

	// Add user Department

	public UserDTO updateUserDepartment(long id , DepartmentDTO departmentDTO){
		User user = userRepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("No Such User Exists !! "));
		Department department = departmentRepository.findByName(departmentDTO.getName()).orElseThrow(() -> new ResourceNotFoundException("No Such Department exists !! "));

		user.setDepartment(department);
		User updatedUser = userRepo.save(user);

		return convertToDTO(updatedUser);
	}

	// Loading User for UserDetailsService

	public UserDetailsService userDetailsService(){
		return new UserDetailsService() {
			@Override
			public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
				return userRepo.findByEmail(username).orElseThrow(() -> new ResourceNotFoundException("User Not Found !"));
			}
		};
	}

	// ModelMapper Methods to Map DTO and ENTITY 
	
	private UserDTO convertToDTO(User employee) {
		return modelMapper.map(employee, UserDTO.class);
	}
	
	private User convertToEntity(UserDTO employeeDto) {
		return modelMapper.map(employeeDto, User.class);
	}
}
