package com.employee_portal.employeePortal.service;

import org.springframework.security.core.userdetails.UserDetails;

import java.util.Map;

public interface JWTService {

    String generateToken(UserDetails userDetails , long id);

    String extractUserName(String token);

    boolean isTokenValid(String token , UserDetails userDetails);

}
