package com.employee_portal.employeePortal.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "ADDRESS")
public class Address {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;

	private String houseNo;
	private String street;
	private String city;
	private String zip;
	private String state;
	private String country;
	
	
	@OneToOne(mappedBy = "address", cascade = CascadeType.MERGE)
	private User user;

	public Address(String houseNo, String street, String city, String zip, String state, String country,
			User user) {
		super();
		this.houseNo = houseNo;
		this.street = street;
		this.city = city;
		this.zip = zip;
		this.state = state;
		this.country = country;
		this.user = user;
	}

	public Address(long id ,String houseNo, String street, String city, String zip, String state, String country) {
		super();
		this.id = id;
		this.houseNo = houseNo;
		this.street = street;
		this.city = city;
		this.zip = zip;
		this.state = state;
		this.country = country;
	}


}
