package com.employee_portal.employeePortal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.employee_portal.employeePortal.dto.DepartmentDTO;
import com.employee_portal.employeePortal.service.DepartmentService;

@RestController
@RequestMapping("/admin/department")
@CrossOrigin(origins = "http://localhost:4200")
public class DepartmentController {
	
	@Autowired
	DepartmentService departmentService;
	
	
	// Get All Departments 
	
	@GetMapping
	public ResponseEntity<List<DepartmentDTO>> getAllDepartments(){		
		return new ResponseEntity<List<DepartmentDTO>>(departmentService.getAllDepartments(),HttpStatus.OK);
	}
	
	
	// Get Department By Id
	
	@GetMapping("/{id}")
	public ResponseEntity<DepartmentDTO> getDepartmentById(@PathVariable long id) {
		return new ResponseEntity<DepartmentDTO>( departmentService.getById(id),HttpStatus.OK);
	}
	
	
	// Create Department 
	
	@PostMapping
	public ResponseEntity<DepartmentDTO> createDepartment(@RequestBody DepartmentDTO departmentDtoRequest){
		return new ResponseEntity<DepartmentDTO>(departmentService.createDepartment(departmentDtoRequest),HttpStatus.CREATED);
	}
	

	// Update Department
	
	@PutMapping("/{id}")
	public ResponseEntity<DepartmentDTO> updateDepartment(@PathVariable long id , @RequestBody DepartmentDTO departmentDto){
		return new ResponseEntity<DepartmentDTO>(departmentService.updateDepartment(id, departmentDto),HttpStatus.OK);
	}


	//Delete Department 
	
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteDepartment(@PathVariable long id){
		departmentService.deleteById(id);
		return new ResponseEntity<String>("Department Deleted Successfully !!!" , HttpStatus.OK);
	}
}
