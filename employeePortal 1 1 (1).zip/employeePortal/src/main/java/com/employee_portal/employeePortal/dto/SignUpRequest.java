package com.employee_portal.employeePortal.dto;

import com.employee_portal.employeePortal.entity.Address;
import com.employee_portal.employeePortal.entity.Role;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class SignUpRequest {

    private String name;
    private String email;
    private String password;
    private Role role;
    private Address address = new Address();
}
