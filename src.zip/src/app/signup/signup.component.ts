import { Component } from '@angular/core';
import { User } from '../entity/User';
import { AuthenticationService } from '../service/authentication.service';
import { Department } from '../entity/Department';
import { Address } from '../entity/Address';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrl: './signup.component.css'
})

export class SignupComponent {

  errorMessage = '';
  
  user : User = {
    name: '',
    email: '',
    userId: '',
    contactNo: '',
    role: 'EMPLOYEE',
    location: '',
    password: '',
    department: {} as Department,
    id: 0,
    address: {} as Address
  }

  constructor(
    public authService:AuthenticationService,
    private router:Router 
  ){}

  get isFormValid() :boolean {
      return this.user.name != '' && this.user.password != '' && this.user.email != '';
  }

  handleSignUp(){
    if(this.user.name != '' && this.user.password != '' && this.user.email != ''){
      this.authService.signup(this.user)
      .subscribe({
        next: () => 
            {
              this.router.navigate(['signin']);
            },
        error: () => {
          this.errorMessage = `Resgistration Failed ! `;
        }
     });
    }
    else{
      this.errorMessage = 'Please enter all Fields !';
    }
  }
}
