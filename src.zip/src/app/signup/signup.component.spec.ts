import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';
import { SignupComponent } from './signup.component';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { User } from '../entity/User';
import { Address } from '../entity/Address';
import { Department } from '../entity/Department';
import { of } from 'rxjs';

describe('Sign Up Component ', () => {
  let component: SignupComponent;
  let fixture: ComponentFixture<SignupComponent>;
  let mockAuthService: jasmine.SpyObj<AuthenticationService>;
  let mockRouter: jasmine.SpyObj<Router>;

  beforeEach(async () => {
    const authServiceSpy = jasmine.createSpyObj('AuthenticationService', [
      'signup',
    ]);
    const routerSpy = jasmine.createSpyObj('Router', ['navigate']);

    await TestBed.configureTestingModule({
      declarations: [SignupComponent],
      providers: [
        { provide: AuthenticationService, useValue: authServiceSpy },
        { provide: Router, useValue: routerSpy },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(SignupComponent);
    component = fixture.componentInstance;
    mockAuthService = TestBed.inject(
      AuthenticationService
    ) as jasmine.SpyObj<AuthenticationService>;
    mockRouter = TestBed.inject(Router) as jasmine.SpyObj<Router>;
  });

  beforeEach(() => {
    localStorage.clear();
  });

  const mockUser: User = {
    id: 1,
    name: '',
    email: '',
    userId: '',
    contactNo: '',
    role: 'EMPLOYEE',
    location: '',
    password: '',
    department: {} as Department,
    address: {} as Address,
  };

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should validate form ' , () => {
    component.user.name = 'user';
    component.user.email = 'user@gmail.com';
    component.user.password = 'user123';
    expect(component.isFormValid).toBeTrue();

    component.user.name = '';
    expect(component.isFormValid).toBeFalse();

    component.user.name = 'user';
    component.user.password = '';
    expect(component.isFormValid).toBeFalse();

    component.user.password = 'user123';
    component.user.email = '';
    expect(component.isFormValid).toBeFalse();
  })

  it('should handle the signUp ' , () => {
    component.user.name = 'user';
    component.user.email = 'user@gmail.com';
    component.user.password = 'user123';
    expect(component.isFormValid).toBeTrue();

    mockAuthService.signup.and.returnValue(of(mockUser))

    component.handleSignUp();

    expect(mockAuthService.signup).toHaveBeenCalledWith(component.user);
    expect(mockRouter.navigate).toHaveBeenCalledWith(['signin']);

  })

});
