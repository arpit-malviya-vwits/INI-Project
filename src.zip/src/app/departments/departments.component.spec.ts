import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DepartmentsComponent } from './departments.component';
import { DepartmentService } from '../service/department.service';
import { Department } from '../entity/Department';
import { of } from 'rxjs';
import { FormsModule } from '@angular/forms';

describe('DepartmentsComponent', () => {
  let component: DepartmentsComponent;
  let fixture: ComponentFixture<DepartmentsComponent>;
  let mockDepartmentService: jasmine.SpyObj<DepartmentService>;

  beforeEach(async () => {
    const departmentServiceSpy = jasmine.createSpyObj('DepartmentService', [
      'getAllDepartments',
      'createDepartment',
      'deleteDepartment',
      'getDepartmentById',
      'updatedDepartment',
    ]);

    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, FormsModule],
      declarations: [DepartmentsComponent],
      providers: [
        { provide: DepartmentService, useValue: departmentServiceSpy },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(DepartmentsComponent);
    component = fixture.componentInstance;
    mockDepartmentService = TestBed.inject(
      DepartmentService
    ) as jasmine.SpyObj<DepartmentService>;

    const mockDepartments: Department[] = [
      { id: 1, name: 'Engineering' },
      { id: 2, name: 'Marketing' },
    ];

    mockDepartmentService.getAllDepartments.and.returnValue(
      of(mockDepartments)
    );
  });

  it('should call departments in ngOnInit', () => {
    spyOn(component, 'loadDepartments').and.callThrough();
    component.ngOnInit();
    expect(component.loadDepartments).toHaveBeenCalled();
  });

  it('should populate departments on getDepartments', () => {
    component.loadDepartments();
    fixture.detectChanges();
    expect(component.departments.length).toBe(2);
    expect(component.departments[0].name).toBe('Engineering');
  });

  it('should call addDepartment', () => {
    const mockDepartment: Department = { id: 1, name: 'Delivery' };
    component.department = mockDepartment;
    mockDepartmentService.createDepartment.and.returnValue(of(mockDepartment));

    spyOn(window, 'alert');

    component.addDepartmentHandler();
    fixture.detectChanges();

    expect(mockDepartmentService.createDepartment).toHaveBeenCalledWith(
      mockDepartment
    );
    expect(window.alert).toHaveBeenCalledWith(
      'Department Created Successfully !'
    );
  });

  it('should call updateHandler', () => {
    const mockDepartment: Department = { id: 1, name: 'Delivery' };
    component.department = mockDepartment;
    mockDepartmentService.updatedDepartment.and.returnValue(of(mockDepartment));
    spyOn(component, 'ngOnInit');

    component.updateHandler();
    fixture.detectChanges();

    expect(mockDepartmentService.updatedDepartment).toHaveBeenCalledWith(
      1,
      mockDepartment
    );
    expect(component.isGettingUpdated).toBeFalse();
    expect(component.department.id).toBe(0);
    expect(component.department.name).toBe('');
    expect(component.ngOnInit).toHaveBeenCalled();
  });

  //   it('should call deleteDepartmentHandler' , () => {

  //     mockDepartmentService.deleteDepartment.and.returnValue(of());

  //     spyOn(component, 'ngOnInit');
  //     spyOn(window, 'alert');

  //     component.deleteDepartmentHandler(1);
  //     fixture.detectChanges();

  //     expect(mockDepartmentService.deleteDepartment).toHaveBeenCalledWith(1);
  //     expect(component.ngOnInit).toHaveBeenCalled();
  //     expect(window.alert).toHaveBeenCalledWith("Department Deleted Successfully !");
  //   })

  it('should call updateDepartmentHandler', () => {
    const mockDepartment: Department = { id: 1, name: 'Delivery' };
    mockDepartmentService.getDepartmentById.and.returnValue(of(mockDepartment));

    component.updateDepartmentHandler(1);

    expect(mockDepartmentService.getDepartmentById).toHaveBeenCalledWith(1);
    expect(component.department).toEqual(mockDepartment);
    expect(component.isGettingUpdated).toBeTrue();
  });

});
