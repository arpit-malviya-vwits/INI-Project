import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';
import { DepartmentService } from '../service/department.service';
import { Department } from '../entity/Department';

@Component({
  selector: 'app-departments',
  templateUrl: './departments.component.html',
  styleUrl: './departments.component.css'
})
export class DepartmentsComponent implements OnInit{

  departments : Department[] = [];

  department:Department ={
    id:0,
    name:''
  }

  isGettingUpdated: boolean = false;

  constructor(
    private departmentService:DepartmentService
  ){}

ngOnInit(): void {
  this.loadDepartments();
}

loadDepartments(){
  this.departmentService.getAllDepartments()
    .subscribe(
      (data) =>  this.departments = data
    )
}

addDepartmentHandler() {
  if(this.department.name){
    this.departmentService.createDepartment(this.department)
        .subscribe( () => {
          this.department.name = '';
          this.ngOnInit();
        }) 
  }

  alert("Department Created Successfully !")
}

updateDepartmentHandler(id: number) {

  this.isGettingUpdated = true;
  
  this.departmentService.getDepartmentById(id)
    .subscribe(
      (data) => this.department = data
    )
}

deleteDepartmentHandler(id:number) {
  this.departmentService.deleteDepartment(id)
      .subscribe(
        () => {
          this.ngOnInit()
        }
      );

      alert("Department Deleted Successfully !")
      window.location.reload();
}

updateHandler(){
  this.departmentService.updatedDepartment(this.department.id,this.department)
      .subscribe(
        () => this.ngOnInit()
      );

      this.isGettingUpdated = false;
      this.department.id = 0;
      this.department.name = '';
}
}
