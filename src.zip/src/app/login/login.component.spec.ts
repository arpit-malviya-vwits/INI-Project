import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LoginComponent } from './login.component';
import { AuthenticationService } from '../service/authentication.service';
import { Router } from '@angular/router';
import { of } from 'rxjs';

describe('Login Component', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let mockAuthService: jasmine.SpyObj<AuthenticationService>;
  let mockRouter: jasmine.SpyObj<Router>;

  beforeEach(async () => {
    const authServiceSpy = jasmine.createSpyObj('AuthenticationService', [
      'login',
      'hasAuthority',
      'getuserId',
    ]);
    const routerSpy = jasmine.createSpyObj('Router', ['navigate']);

    await TestBed.configureTestingModule({
      declarations: [LoginComponent],
      providers: [
        { provide: AuthenticationService, useValue: authServiceSpy },
        { provide: Router, useValue: routerSpy },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    mockAuthService = TestBed.inject(
      AuthenticationService
    ) as jasmine.SpyObj<AuthenticationService>;
    mockRouter = TestBed.inject(Router) as jasmine.SpyObj<Router>;

  });

  beforeEach(() => {
    localStorage.clear();
  })

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call handleLogin ', () => {
    const mockCredentials = {email:"demo@gmail.com",password:"demo123"}
    const token = 'fake-token';
    const role = 'USER';
    const id = '1';

    component.credentials = mockCredentials;
    mockAuthService.login.and.returnValue(of(token))
    mockAuthService.getuserId.and.returnValue(of(id))
    mockAuthService.hasAuthority.and.returnValue(of(role))

    component.handleLogin();

    expect(mockAuthService.login).toHaveBeenCalledWith(component.credentials);
    expect(mockRouter.navigate).toHaveBeenCalledWith(['welcome']);
  })

  it('should validate form correctly', () => {
    component.credentials.email = 'user@gmail.com';
    component.credentials.password = 'password';
    expect(component.isFormValid).toBeTrue();

    component.credentials.email = '';
    component.credentials.password = 'password';
    expect(component.isFormValid).toBeFalse();

    component.credentials.email = 'user@gmail.com';
    component.credentials.password = '';
    expect(component.isFormValid).toBeFalse();

    component.credentials.email = '';
    component.credentials.password = '';
    expect(component.isFormValid).toBeFalse();
  });

});
