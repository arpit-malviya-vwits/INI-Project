import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})

export class LoginComponent implements OnInit{

  credentials = {
    email: '',
    password: ''
  };

  errorMessage = '';

  get isFormValid(): boolean {
    return this.credentials.email.trim() !== '' && this.credentials.password.trim() !== '';
  }

  constructor(
    private router: Router,
    private authService: AuthenticationService
  ) { }

  ngOnInit(): void {
    
  }

  handleLogin() {
    this.authService.login(this.credentials)
      .subscribe({
        next: (data: any) =>
          {
          localStorage.setItem('token', data.token);
          const role = this.authService.hasAuthority();
          localStorage.setItem('role', role);
          const id = this.authService.getuserId();
          localStorage.setItem('id',id);
          this.router.navigate(['welcome']);
        },
        error : () =>{
          this.errorMessage = 'invalid Credentials !';
        }
      });
  }

}
