import { Component, OnInit } from '@angular/core';
import { Department } from '../entity/Department';
import { User } from '../entity/User';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../service/user.service';
import { DepartmentService } from '../service/department.service';
import { Address } from '../entity/Address';

@Component({
  selector: 'app-update-user',
  templateUrl: './update-user.component.html',
  styleUrl: './update-user.component.css',
})
export class UpdateUserComponent implements OnInit {
  user: User = {
    name: '',
    email: '',
    userId: '',
    contactNo: '',
    role: '',
    location: '',
    password: '',
    department: {} as Department,
    id: 0,
    address: {} as Address,
  };

  departments: Department[] = [];

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private userService: UserService,
    private departmentService: DepartmentService
  ) {}

  id: any;

  ngOnInit(): void {
    this.getDepartments();

    this.id = this.route.snapshot.paramMap.get('id');

    this.userService.getEmployeeById(Number(this.id)).subscribe((data) => {
      this.user = data;
      this.user.address = data.address;
    });
  }

  getDepartments() {
    this.departmentService
      .getAllDepartments()
      .subscribe((data) => (this.departments = data));
  }

  updateUserHandler() {
    this.userService
      .updatedEmployee(Number(this.id), this.user)
      .subscribe(() => this.router.navigateByUrl('manage-user'));

    alert('User Updated Successfully !!');
  }

  cancelUserHandler() {
    this.router.navigateByUrl('manage-user');
  }
}
