import { Address } from "./Address";
import { Department } from "./Department";

export interface User{
    id:number;
    name:string;
    email:string;
    userId:string;
    contactNo:string;
    role:string;
    location:string;
    password:string;
    department:Department;
    address:Address;
}
