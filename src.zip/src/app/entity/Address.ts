export interface Address{
    id:number;
    houseNo:string;
    street:string;
    city:string;
    zip:string;
    state:string;
    country:string;
}

export class Address{
    constructor(
    public id:number,
    public houseNo:string,
    public street:string,
    public city:string,
    public zip:string,
    public state:string,
    public country:string,
    ){}
}