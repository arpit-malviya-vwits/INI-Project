import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Department } from '../entity/Department';

@Injectable({
  providedIn: 'root'
})
export class DepartmentService {

  private baseUrl = 'http://localhost:8080/admin/department';

  constructor(private http:HttpClient) { }

  
  getAllDepartments(){
    return this.http.get<Department[]>(`${this.baseUrl}`);
  }

  getDepartmentById(id:number){
    return this.http.get<Department>(`${this.baseUrl}/${id}`);
  }

  createDepartment(department:Department){
    return this.http.post<Department>(`${this.baseUrl}`,department);
  }  

  updatedDepartment(id:number,department:Department){
    return this.http.put<Department>(`${this.baseUrl}/${id}`,department);
  }

  deleteDepartment(id:number){
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }
}
