import { TestBed } from '@angular/core/testing';
import {
  HttpClientTestingModule,
  HttpTestingController,
} from '@angular/common/http/testing';
import { Router } from '@angular/router';
import { AuthenticationService } from './authentication.service';
import { User } from '../entity/User';
import { JwtHelperService, JWT_OPTIONS } from '@auth0/angular-jwt';
import { Department } from '../entity/Department';
import { Address } from '../entity/Address';

describe('AuthenticationService', () => {
  let service: AuthenticationService;
  let httpMock: HttpTestingController;
  let router: Router;
  let jwtHelper: JwtHelperService;

  const baseUrl = 'http://localhost:8080/auth';

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        AuthenticationService,
        JwtHelperService,
        {
          provide: Router,
          useValue: { navigate: jasmine.createSpy('navigate') },
        },
        {
          provide: JWT_OPTIONS,
          useValue: {},
        },
      ],
    });

    service = TestBed.inject(AuthenticationService);
    httpMock = TestBed.inject(HttpTestingController);
    router = TestBed.inject(Router);
    jwtHelper = TestBed.inject(JwtHelperService);

    spyOn(localStorage, 'removeItem').and.callFake(() => {});
  });

  afterEach(() => {
    httpMock.verify();
  });

  const mockDepartment: Department = { id: 1, name: 'Delivery' };

  const address1: Address = {
    id: 1,
    houseNo: '123 A',
    street: 'street',
    city: 'Pune',
    zip: '12345',
    state: 'UP',
    country: 'India',
  };

  const mockUser: User = {
    id: 1,
    name: 'user',
    email: 'user@example.com',
    userId: 'abcd',
    contactNo: '8989898989',
    role: 'EMPLOYEE',
    location: 'pune',
    password: 'user',
    department: mockDepartment,
    address: address1,
  };

  const mockToken =
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwicm9sZSI6WyJVU0VSIl19.4fHqv59RbK8ktz7G9r8D4V7iG90J8pPUeOge1Chl1W0';

  const mockDecodedToken = {
    id: 1,
    role: [{ authority: 'USER' }],
  };

  it('should authenticate user and return a token', () => {
    const credentials = { username: 'test', password: 'test' };

    service.login(credentials).subscribe((response) => {
      expect(response).toEqual(mockToken);
    });

    const req = httpMock.expectOne(`${baseUrl}/signin`);
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual(credentials);
  });

  it('should register a new user', () => {
    service.signup(mockUser).subscribe((response) => {
      expect(response).toEqual(mockUser);
    });

    const req = httpMock.expectOne(`${baseUrl}/signup`);
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual(mockUser);
    req.flush(mockUser);
  });

  it('should return the authority from the token if available', () => {
    spyOn(localStorage, 'getItem').and.returnValue(mockToken);
    spyOn(jwtHelper, 'decodeToken').and.returnValue(mockDecodedToken);

    const authority = service.hasAuthority();
    expect(authority).toBe(undefined);
  });

  it('should return null if token is not available', () => {
    spyOn(localStorage, 'getItem').and.returnValue(null);

    const authority = service.hasAuthority();
    expect(authority).toBeNull();
  });

  it('should return the user ID from the token if available', () => {
    spyOn(localStorage, 'getItem').and.returnValue(mockToken);
    spyOn(jwtHelper, 'decodeToken').and.returnValue(mockDecodedToken);

    const userId = service.getuserId();
    expect(userId).toBe(1);
  });

  it('should return null if token is not available', () => {
    spyOn(localStorage, 'getItem').and.returnValue(null);

    const userId = service.getuserId();
    expect(userId).toBeNull();
  });

  it('should return true if token is present', () => {
    spyOn(localStorage, 'getItem').and.returnValue(mockToken);

    const isLoggedIn = service.isUserLoggedIn();
    expect(isLoggedIn).toBeTrue();
  });

  it('should return false if token is not present', () => {
    spyOn(localStorage, 'getItem').and.returnValue(null);

    const isLoggedIn = service.isUserLoggedIn();
    expect(isLoggedIn).toBeFalse();
  });

  it('should return true if role is ADMIN', () => {
    spyOn(localStorage, 'getItem').and.returnValue('ADMIN');

    const isAdmin = service.isAdmin();
    expect(isAdmin).toBeTrue();
  });

  it('should return false if role is not ADMIN', () => {
    spyOn(localStorage, 'getItem').and.returnValue('USER');

    const isAdmin = service.isAdmin();
    expect(isAdmin).toBeFalse();
  });

  it('should remove token, role, and id from local storage and navigate to signin', () => {
    service.logout();
    expect(localStorage.removeItem).toHaveBeenCalledWith('token');
    expect(localStorage.removeItem).toHaveBeenCalledWith('role');
    expect(localStorage.removeItem).toHaveBeenCalledWith('id');
    //   expect(router.navigate).toHaveBeenCalledWith(['signin']);
  });
});
