import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, GuardResult, MaybeAsync, RouterStateSnapshot } from '@angular/router';
import { AuthenticationService } from './authentication.service';

@Injectable({
  providedIn: 'root'
})
export class RouteGuardService implements CanActivate {

  constructor(
    private authService:AuthenticationService
  ) { }

  role = ''

  // This is a route Guard for Only Admin

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot){

    this.role = this.authService.hasAuthority();
    
    if(this.authService.isUserLoggedIn() && this.role === "ADMIN"){
      return true;
    }
    return false;
  }
}
