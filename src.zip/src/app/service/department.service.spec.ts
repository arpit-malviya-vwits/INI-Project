import {
  HttpClientTestingModule,
  HttpTestingController,
} from '@angular/common/http/testing';
import { Department } from '../entity/Department';
import { DepartmentService } from './department.service';
import { TestBed } from '@angular/core/testing';

describe('Department Service', () => {
  let service: DepartmentService;
  let httpMock: HttpTestingController;

  const baseUrl = 'http://localhost:8080/admin/department';

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [DepartmentService],
    });

    service = TestBed.inject(DepartmentService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  const mockDepartments: Department[] = [
    { id: 1, name: 'Delivery' },
    { id: 2, name: 'Engineering' },
  ];

  const mockDepartment: Department = { id: 1, name: 'Delivery' };

  it('should return an array of departments', () => {
    service.getAllDepartments().subscribe((departments) => {
      expect(departments.length).toBe(2);
      expect(departments).toEqual(mockDepartments);
    });

    const req = httpMock.expectOne(`${baseUrl}`);
    expect(req.request.method).toBe('GET');
    req.flush(mockDepartments);
  });

  it('should return a department', () => {
    service.getDepartmentById(mockDepartment.id).subscribe((department) => {
      expect(department).toEqual(mockDepartment);
    });

    const req = httpMock.expectOne(`${baseUrl}/1`);
    expect(req.request.method).toBe('GET');
    req.flush(mockDepartment);
  });

  it('should create a new department', () => {
    service.createDepartment(mockDepartment).subscribe((department) => {
      expect(department).toEqual(mockDepartment);
    });

    const req = httpMock.expectOne(`${baseUrl}`);
    expect(req.request.method).toBe('POST');
    req.flush(mockDepartment);
  });

  it('should update an existing department', () => {
    service.updatedDepartment(1, mockDepartment).subscribe((department) => {
      expect(department).toEqual(mockDepartment);
    });

    const req = httpMock.expectOne(`${baseUrl}/1`);
    expect(req.request.method).toBe('PUT');
    req.flush(mockDepartment);
  });

  it('should delete Department by Id', () => {
    service.deleteDepartment(1).subscribe((response) => {
      expect(response).toBeUndefined();
    });

    const req = httpMock.expectOne(`${baseUrl}/1`);
    expect(req.request.method).toBe('DELETE');
  });
});
