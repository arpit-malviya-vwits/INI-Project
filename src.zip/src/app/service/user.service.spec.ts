import { TestBed } from '@angular/core/testing';
import {
  HttpClientTestingModule,
  HttpTestingController,
} from '@angular/common/http/testing';
import { UserService } from './user.service';
import { User } from '../entity/User';
import { Department } from '../entity/Department';
import { Address } from '../entity/Address';

describe('UserService', () => {
  let service: UserService;
  let httpMock: HttpTestingController;

  const baseUrl = 'http://localhost:8080/user';

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [UserService],
    });

    service = TestBed.inject(UserService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  const mockDepartment: Department = { id: 1, name: 'Delivery' };

  const address1: Address = {
    id: 1,
    houseNo: '123 A',
    street: 'street',
    city: 'Pune',
    zip: '12345',
    state: 'UP',
    country: 'India',
  };

  const address2: Address = {
    id: 2,
    houseNo: '123 B',
    street: 'street',
    city: 'Pune',
    zip: '12345',
    state: 'UP',
    country: 'India',
  };

  const mockUser: User = {
    id: 1,
    name: 'user',
    email: 'user@example.com',
    userId: 'abcd',
    contactNo: '8989898989',
    role: 'EMPLOYEE',
    location: 'pune',
    password: 'user',
    department: mockDepartment,
    address: address1,
  };

  const mockUsers: User[] = [
    {
      id: 1,
      name: 'user',
      email: 'user@example.com',
      userId: 'abcd',
      contactNo: '8989898989',
      role: 'EMPLOYEE',
      location: 'pune',
      password: 'user',
      department: mockDepartment,
      address: address1,
    },
    {
      id: 2,
      name: 'user',
      email: 'user@example.com',
      userId: 'abcd',
      contactNo: '8989898989',
      role: 'EMPLOYEE',
      location: 'pune',
      password: 'user',
      department: mockDepartment,
      address: address2,
    },
  ];

  // Get All Users

  it('should return an array of users', () => {
    service.getAllEmployees().subscribe((users) => {
      expect(users.length).toBe(2);
      expect(users).toEqual(mockUsers);
    });

    const req = httpMock.expectOne(`${baseUrl}`);
    expect(req.request.method).toBe('GET');
    req.flush(mockUsers);
  });

  // Get User By ID

  it('should return an user of given id', () => {
    service.getEmployeeById(1).subscribe((user) => {
      expect(user).toEqual(mockUser);
    });

    const req = httpMock.expectOne(`${baseUrl}/1`);
    expect(req.request.method).toBe('GET');
    req.flush(mockUser);
  });

  // Create User

  it('should create a user', () => {
    service.createEmployee(mockUser).subscribe((user) => {
      expect(user).toEqual(mockUser);
    });

    const req = httpMock.expectOne(`${baseUrl}`);
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual(mockUser);
    req.flush(mockUser);
  });

  //Update User

  it('should update a user', () => {
    service.updatedEmployee(1, mockUser).subscribe((user) => {
      expect(user).toEqual(mockUser);
    });

    const req = httpMock.expectOne(`${baseUrl}/1`);
    expect(req.request.method).toBe('PUT');
    expect(req.request.body).toEqual(mockUser);
    req.flush(mockUser);
  });

  // Delete User

  it('should delete a user', () => {
    service.deleteEmployee(1).subscribe((response) => {
      expect(response).toBeUndefined();
    });

    const req = httpMock.expectOne(`${baseUrl}/1`);
    expect(req.request.method).toBe('DELETE');
  });
});
