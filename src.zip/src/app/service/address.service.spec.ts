import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AddressService } from './address.service';
import { Address } from '../entity/Address';

describe('AddressService', () => {
  let service: AddressService;
  let httpMock: HttpTestingController;

  const baseUrl = 'http://localhost:8080/user/address';

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [AddressService]
    });

    service = TestBed.inject(AddressService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  const mockAddresses: Address[] = [
    { id: 1, houseNo: '123 A', street:'street', city: 'Pune', zip: '12345' ,state:'UP',country:'India'},
    { id: 2, houseNo: '123 B', street:'street', city: 'Goa', zip: '12345' ,state:'UP',country:'India'}
  ];

  const mockAddress: Address = { id: 1,  houseNo: '123 A', street:'street', city: 'Pune', zip: '12345' ,state:'UP',country:'India'};

  // Get All Addresses

 
    it('should return an array of addresses', () => {

      service.getAllAddresses().subscribe((addresses) => {
        expect(addresses.length).toBe(2);
        expect(addresses).toEqual(mockAddresses);
      })

      const req = httpMock.expectOne(`${baseUrl}`);
      expect(req.request.method).toBe('GET');
      req.flush(mockAddresses);
    });
  


    it('should return a single address by id', () => {
      service.getAddressById(1).subscribe((address) => {
        expect(address).toEqual(mockAddress);
      });

      const req = httpMock.expectOne(`${baseUrl}/1`);
      expect(req.request.method).toBe('GET');
      req.flush(mockAddress);
    });



    it('should create a new address', () => {
      service.createAddress(mockAddress).subscribe((address) => {
        expect(address).toEqual(mockAddress);
      });

      const req = httpMock.expectOne(`${baseUrl}`);
      expect(req.request.method).toBe('POST');
      req.flush(mockAddress);
    });

    it('should update an address by id', () => {
      service.updatedAddress(1, mockAddress).subscribe((address) => {
        expect(address).toEqual(mockAddress);
      });

      const req = httpMock.expectOne(`${baseUrl}/1`);
      expect(req.request.method).toBe('PUT');
      req.flush(mockAddress);
    });

    it('should delete an address by id', () => {
      service.deleteAddress(1).subscribe((response) => {
        expect(response).toBeUndefined();
      });

      const req = httpMock.expectOne(`${baseUrl}/1`);
      expect(req.request.method).toBe('DELETE');
    });

});
