import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from '../entity/User';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  private baseUrl = 'http://localhost:8080/user';

  constructor(private http: HttpClient) {}

  getAllEmployees() {
    return this.http.get<User[]>(`${this.baseUrl}`);
  }

  getEmployeeById(id: number) {
    return this.http.get<User>(`${this.baseUrl}/${id}`);
  }

  createEmployee(user: User) {
    return this.http.post<User>(`${this.baseUrl}`, user);
  }

  updatedEmployee(id: number, user: User) {
    return this.http.put<User>(`${this.baseUrl}/${id}`, user);
  }

  deleteEmployee(id: number) {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }
}
