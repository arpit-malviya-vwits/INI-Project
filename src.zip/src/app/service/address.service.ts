import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Address } from '../entity/Address';

@Injectable({
  providedIn: 'root'
})
export class AddressService {

  private baseUrl = 'http://localhost:8080/user/address';

  constructor(
    private http:HttpClient
  ) { }

   
  getAllAddresses(){
    return this.http.get<Address[]>(`${this.baseUrl}`);
  }

  getAddressById(id:number){
    return this.http.get<Address>(`${this.baseUrl}/${id}`);
  }

  createAddress(address:Address){
    return this.http.post<Address>(`${this.baseUrl}`,address);
  }  

  updatedAddress(id:number,address:Address){
    return this.http.put<Address>(`${this.baseUrl}/${id}`,address);
  }

  deleteAddress(id:number){
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }

}
