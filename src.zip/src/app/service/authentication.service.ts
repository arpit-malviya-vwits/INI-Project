import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from '../entity/User';
import { JwtHelperService } from '@auth0/angular-jwt';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  private pathUrl = 'http://localhost:8080/auth';
  private jwtHelper = new JwtHelperService;

  private isLocalStorageAvailable = typeof localStorage !== 'undefined';

  constructor( 
    private http:HttpClient,
    private route : Router
  ) {}

  login(credentials:any){
    return this.http.post(`${this.pathUrl}/signin`,credentials);
  }

  signup(user:User){
    return this.http.post(`${this.pathUrl}/signup`,user);
  }


  hasAuthority():any{
    if(this.isLocalStorageAvailable){
      const token = localStorage.getItem('token');
      if(token){
        const decodedToken = this.jwtHelper.decodeToken(token);
        return decodedToken.role[0].authority;
      }
    }
    return null;
  }

  getuserId():any{
    const token = localStorage.getItem('token');
    if(token){
      const decodedToken = this.jwtHelper.decodeToken(token);
      return decodedToken.id;
    }
    return null;
  }

  public isUserLoggedIn():boolean{
    if(this.isLocalStorageAvailable){
      const token = localStorage.getItem('token');
      return token != null;
    }
    return false;
  }

  public isAdmin(){
    const role = localStorage.getItem('role');
    return role === 'ADMIN';
  }

  logout(){
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    localStorage.removeItem('id');
    this.route.navigate(['signin']);
  }

}
