import { Component, OnInit } from '@angular/core';
import { UserService } from '../service/user.service';
import { Department } from '../entity/Department';
import { DepartmentService } from '../service/department.service';
import { User } from '../entity/User';
import { Router } from '@angular/router';
import { Address } from '../entity/Address';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrl: './add-user.component.css',
})
export class AddUserComponent implements OnInit {
  user: User = {
    name: '',
    email: '',
    userId: '',
    contactNo: '',
    role: '',
    location: '',
    password: '',
    department: {} as Department,
    id: 0,
    address: {} as Address,
  };

  departments: Department[] = [];

  constructor(
    private userService: UserService,
    private departmentService: DepartmentService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.getDepartments();
  }

  getDepartments() {
    this.departmentService.getAllDepartments().subscribe((data) => {
      this.departments = data;
    });
  }

  deleteUserHandler() {
    this.router.navigate(['manage-user']);
    alert('User Deleted Successfully!!');
  }

  createUserHandler() {
    this.userService.createEmployee(this.user).subscribe((data) => {
      this.router.navigateByUrl('manage-user');
    });
    alert('User Created Successfully!!');
  }
}
