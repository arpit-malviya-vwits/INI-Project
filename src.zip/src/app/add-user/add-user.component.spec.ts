import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Router } from '@angular/router';
import { of } from 'rxjs';
import { FormsModule } from '@angular/forms';
import { AddUserComponent } from './add-user.component';
import { UserService } from '../service/user.service';
import { DepartmentService } from '../service/department.service';
import { User } from '../entity/User';
import { Department } from '../entity/Department';
import { Address } from '../entity/Address';

describe('AddUserComponent', () => {
  let component: AddUserComponent;
  let fixture: ComponentFixture<AddUserComponent>;
  let userService: jasmine.SpyObj<UserService>;
  let departmentService: jasmine.SpyObj<DepartmentService>;
  let router: jasmine.SpyObj<Router>;

  beforeEach(() => {
    const userServiceSpy = jasmine.createSpyObj('UserService', ['createEmployee',]);
    const departmentServiceSpy = jasmine.createSpyObj('DepartmentService', ['getAllDepartments',]);
    const routerSpy = jasmine.createSpyObj('Router', ['navigate','navigateByUrl',]);

    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, FormsModule],
      declarations: [AddUserComponent],
      providers: [
        { provide: UserService, useValue: userServiceSpy },
        { provide: DepartmentService, useValue: departmentServiceSpy },
        { provide: Router, useValue: routerSpy },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(AddUserComponent);
    component = fixture.componentInstance;
    userService = TestBed.inject(UserService) as jasmine.SpyObj<UserService>;
    departmentService = TestBed.inject(
      DepartmentService
    ) as jasmine.SpyObj<DepartmentService>;
    router = TestBed.inject(Router) as jasmine.SpyObj<Router>;

    const mockDepartments: Department[] = [
      { id: 1, name: 'Engineering' },
      { id: 2, name: 'Marketing' },
    ];
    departmentService.getAllDepartments.and.returnValue(of(mockDepartments));
  });

  it('should call getDepartments on ngOnInit', () => {
    spyOn(component, 'getDepartments').and.callThrough();
    component.ngOnInit();
    expect(component.getDepartments).toHaveBeenCalled();
  });

  it('should populate departments on getDepartments', () => {
    component.getDepartments();
    fixture.detectChanges();
    expect(component.departments.length).toBe(2);
    expect(component.departments[0].name).toBe('Engineering');
  });

  it('should call createEmployee and navigate to manage-user on createUserHandler', () => {
    const user: User = {
      name: 'User',
      email: 'user@example.com',
      userId: 'user123',
      contactNo: '1234567890',
      role: 'USER',
      location: 'Pune',
      password: 'password',
      department: { id: 1, name: 'Engineering' } as Department,
      id: 1,
      address: {} as Address,
    };

    component.user = user;
    userService.createEmployee.and.returnValue(of(user));
    spyOn(window, 'alert');

    component.createUserHandler();
    fixture.detectChanges();

    expect(userService.createEmployee).toHaveBeenCalledWith(user);
    expect(router.navigateByUrl).toHaveBeenCalledWith('manage-user');
    expect(window.alert).toHaveBeenCalledWith('User Created Successfully!!');
  });

  it('should navigate to manage-user and show alert on deleteUserHandler', () => {
    spyOn(window, 'alert');

    component.deleteUserHandler();
    fixture.detectChanges();

    expect(router.navigate).toHaveBeenCalledWith(['manage-user']);
    expect(window.alert).toHaveBeenCalledWith('User Deleted Successfully!!');
  });
});
