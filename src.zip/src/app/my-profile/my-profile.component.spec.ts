import { ComponentFixture, TestBed } from "@angular/core/testing";
import { MyProfileComponent } from "./my-profile.component";
import { UserService } from "../service/user.service";
import { AddressService } from "../service/address.service";
import { User } from "../entity/User";
import { Department } from "../entity/Department";
import { Address } from "../entity/Address";
import { of } from "rxjs";

describe('My Profile Component ', () => {
  let component: MyProfileComponent;
  let fixture: ComponentFixture<MyProfileComponent>;
  let mockUserService: jasmine.SpyObj<UserService>;
  let mockAddressService: jasmine.SpyObj<AddressService>;

  beforeEach(async () => {
    const userServiceSpy = jasmine.createSpyObj('UserService', ['getEmployeeById', 'updatedEmployee']);
    const addressServiceSpy = jasmine.createSpyObj('AddressService', ['updatedAddress']);

    await TestBed.configureTestingModule({
      declarations: [MyProfileComponent],
      providers: [
        { provide: UserService, useValue: userServiceSpy },
        { provide: AddressService, useValue: addressServiceSpy }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(MyProfileComponent);
    component = fixture.componentInstance;
    mockUserService = TestBed.inject(UserService) as jasmine.SpyObj<UserService>;
    mockAddressService = TestBed.inject(AddressService) as jasmine.SpyObj<AddressService>;
  })

  beforeEach(() => {
    localStorage.clear();
  });

  const mockDepartment: Department = { id: 1, name: 'Delivery' };

  const address1: Address = {
    id: 1,
    houseNo: '123 A',
    street: 'street',
    city: 'Pune',
    zip: '12345',
    state: 'UP',
    country: 'India',
  };

  const mockUser: User = {
    id: 1,
    name: 'user',
    email: 'user@example.com',
    userId: 'abcd',
    contactNo: '8989898989',
    role: 'EMPLOYEE',
    location: 'pune',
    password: 'user',
    department: mockDepartment,
    address: address1,
  };

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load user data ' , () => {

    localStorage.setItem("id","1");
    mockUserService.getEmployeeById.and.returnValue(of(mockUser));

    component.ngOnInit();

    expect(mockUserService.getEmployeeById).toHaveBeenCalledWith(1);
    expect(component.user).toEqual(mockUser);
    expect(component.address).toEqual(mockUser.address);

  })

  it('should handle save profile ' ,() => {

    localStorage.setItem('id', '1');
    mockUserService.updatedEmployee.and.returnValue(of(mockUser));

    component.user = mockUser;
    component.SaveProfileHandler();

    expect(mockUserService.updatedEmployee).toHaveBeenCalledWith(1,component.user);
    expect(component.isEdit).toBeFalse();
  })

  it('should handle save Address ' , () =>{

    const mockAddress: Address = {
        id: 1,
        houseNo: '123 A',
        street: 'street',
        city: 'Pune',
        zip: '12345',
        state: 'UP',
        country: 'India',
      };

    mockAddressService.updatedAddress.and.returnValue(of(mockAddress));

    component.address = mockAddress;
    component.user = mockUser;
    component.SaveAddressHandler();

    expect(mockAddressService.updatedAddress).toHaveBeenCalledWith(component.user.address.id,component.address);
    expect(component.isAddressEdit).toBeFalse();
  })

  it('should handle edit User ', () => {
    component.editUserHandler();
    expect(component.isEdit).toBeTrue();

    component.CancelProfileEditHandler();
    expect(component.isEdit).toBeFalse();
  });

  it('should handle edit address ', () => {
    component.EditAddressHandler();
    expect(component.isAddressEdit).toBeTrue();

    component.CancelAddressEditHandler();
    expect(component.isAddressEdit).toBeFalse();
  })
  
});
