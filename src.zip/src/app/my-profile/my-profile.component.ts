import { Component, OnInit } from '@angular/core';
import { Address } from '../entity/Address';
import { AddressService } from '../service/address.service';
import { UserService } from '../service/user.service';
import { User } from '../entity/User';
import { Department } from '../entity/Department';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrl: './my-profile.component.css'
})
export class MyProfileComponent implements OnInit {

  private isLocalStorageAvailable = typeof localStorage !== 'undefined';

  address: Address = {
    id: 0,
    houseNo: '',
    street: '',
    zip: '',
    city: '',
    state: '',
    country: '',
  }

  user: User = {
    name: '',
    email: '',
    userId: '',
    contactNo: '',
    role: '',
    location: '',
    password: '',
    department: {} as Department,
    address: {} as Address,
    id: 0
  }

  isEdit: boolean = false;
  isAddressEdit: boolean = false;

  constructor(
    private addressService: AddressService,
    private userService: UserService
  ) { }

  ngOnInit(): void {
    if (this.isLocalStorageAvailable) {
      const id = localStorage.getItem('id');
      if (id) {
        this.userService.getEmployeeById(Number(id))
          .subscribe(
            (data) => {
              this.user = data;

              if(this.user.department === undefined || this.user.department === null){
                this.user.department = new Department(0,'');
              }

              this.address = this.user.address;
            }
          );
      }
    }
  }

  SaveProfileHandler() {
    const id = localStorage.getItem('id');
    if (id) {
      this.userService.updatedEmployee(Number(id), this.user)
        .subscribe(
          (data) => this.user = data
        )
    }
    this.isEdit = false;
  }

  editUserHandler() {
    this.isEdit = true;
  }

  CancelProfileEditHandler() {
    this.isEdit = false;
  }

  SaveAddressHandler() {

      this.addressService.updatedAddress(this.user.address.id, this.address)
        .subscribe(
          (data) => {
            this.address = data;
          }
      )

    this.isAddressEdit = false;
  }

  CancelAddressEditHandler() {
    this.isAddressEdit = false;
  }

  EditAddressHandler() {
    this.isAddressEdit = true;
  }
}
