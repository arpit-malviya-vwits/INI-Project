import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ManageUserComponent } from './manage-user.component';
import { UserService } from '../service/user.service';
import { Router } from '@angular/router';
import { User } from '../entity/User';
import { Department } from '../entity/Department';
import { Address } from '../entity/Address';
import { of } from 'rxjs';

describe('Manage User Component', () => {
  let component: ManageUserComponent;
  let fixture: ComponentFixture<ManageUserComponent>;
  let mockUserService: jasmine.SpyObj<UserService>;
  let mockRouter: jasmine.SpyObj<Router>;

  beforeEach(async () => {
    const userServiceSpy = jasmine.createSpyObj('UserService', [
      'getAllEmployees',
      'deleteEmployee',
    ]);
    const routerSpy = jasmine.createSpyObj('Router', ['navigate']);

    await TestBed.configureTestingModule({
      declarations: [ManageUserComponent],
      providers: [
        { provide: UserService, useValue: userServiceSpy },
        { provide: Router, useValue: routerSpy },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(ManageUserComponent);
    component = fixture.componentInstance;
    mockUserService = TestBed.inject(
      UserService
    ) as jasmine.SpyObj<UserService>;
    mockRouter = TestBed.inject(Router) as jasmine.SpyObj<Router>;
  });

  beforeEach(() => {
    localStorage.clear();
  });

  const mockDepartment: Department = { id: 1, name: 'Delivery' };

  const address1: Address = {
    id: 1,
    houseNo: '123 A',
    street: 'street',
    city: 'Pune',
    zip: '12345',
    state: 'UP',
    country: 'India',
  };

  const address2: Address = {
    id: 2,
    houseNo: '123 B',
    street: 'street',
    city: 'Pune',
    zip: '12345',
    state: 'UP',
    country: 'India',
  };

  const mockUser: User = {
    id: 1,
    name: 'user',
    email: 'user@example.com',
    userId: 'abcd',
    contactNo: '8989898989',
    role: 'EMPLOYEE',
    location: 'pune',
    password: 'user',
    department: mockDepartment,
    address: address1,
  };


  const mockUsers: User[] = [
    {
      id: 1,
      name: 'user1',
      email: 'user@example.com',
      userId: 'abcd',
      contactNo: '8989898989',
      role: 'EMPLOYEE',
      location: 'pune',
      password: 'user',
      department: mockDepartment,
      address: address1,
    },
    {
      id: 2,
      name: 'user',
      email: 'user@example.com',
      userId: 'abcd',
      contactNo: '8989898989',
      role: 'EMPLOYEE',
      location: 'pune',
      password: 'user',
      department: mockDepartment,
      address: address2,
    },
  ];

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load users on init', () => {
    mockUserService.getAllEmployees.and.returnValue(of(mockUsers));

    component.ngOnInit();

    expect(mockUserService.getAllEmployees).toHaveBeenCalled();
    expect(component.users).toEqual(mockUsers);
    expect(component.filterdUser).toEqual(mockUsers);
  });

  it('should filter users based on search data', () => {
    component.users = mockUsers;
    component.filterdUser = mockUsers;

    component.searchData = 'user1';
    component.findData();

    expect(component.filterdUser.length).toBe(1);
    expect(component.filterdUser[0].name).toBe('user1');
  });

  it('should navigate to add-user page when createUserHandler is called', () => {
    component.createUserHandler();
    expect(mockRouter.navigate).toHaveBeenCalledWith(['add-user']);
  });

  it('should navigate to update-user page when updateUserHandler is called', () => {
    const userId = 1;
    component.updateUserHandler(userId);
    expect(mockRouter.navigate).toHaveBeenCalledWith([`update-user/${userId}`]);
  });

//   it('should delete user and reload data when deleteUserHandler is called', () => {
//     const userId = 1;
//     mockUserService.deleteEmployee.and.returnValue(of());
//     spyOn(window, 'alert'); 

//     component.deleteUserHandler(userId);

//     expect(mockUserService.deleteEmployee).toHaveBeenCalledWith(userId);
//     expect(window.alert).toHaveBeenCalledWith('User Deleted Successfully !');

//     expect(mockUserService.getAllEmployees).toHaveBeenCalled();
//   });

});
