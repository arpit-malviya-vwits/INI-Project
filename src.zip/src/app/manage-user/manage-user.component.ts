import { Component, OnInit } from '@angular/core';
import { User } from '../entity/User';
import { Router } from '@angular/router';
import { UserService } from '../service/user.service';


@Component({
  selector: 'app-manage-user',
  templateUrl: './manage-user.component.html',
  styleUrl: './manage-user.component.css'
})
export class ManageUserComponent implements OnInit {

  filterdUser: User[] = [];
  users: User[] = [];
  searchData: string = '';

  constructor(
    private router: Router,
    private userService: UserService
  ) { }

  ngOnInit(): void {
    this.loadUsers();
  }

  findData() {
    if (!this.searchData) {
      this.filterdUser = this.users;
    }
    else {
      const lowerCaseText = this.searchData.toLowerCase();
      this.filterdUser = this.users.filter(user => user.name.toLowerCase().includes(lowerCaseText) || user.email.toLowerCase().includes(lowerCaseText));
    }    
  }

  loadUsers(): void {
    this.userService.getAllEmployees()
      .subscribe(
        data => {
          console.log;
          this.users = data;
          this.filterdUser = data;
        });
  }

  createUserHandler() {
    this.router.navigate(['add-user']);
  }

  updateUserHandler(id: number) {
    this.router.navigate([`update-user/${id}`]);
  }

  deleteUserHandler(id: number) {
    this.userService.deleteEmployee(id).subscribe(
      () => this.ngOnInit()
    );
    alert("User Deleted Successfully !")
    window.location.reload()
  }
  

}
